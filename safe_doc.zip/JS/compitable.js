// check browser compitable 
function checkBrowser(){
	if (navigator.userAgent.indexOf("MSIE")!= -1) {
		document.getElementById("webpage").style.display ="none";
		document.body.innerHTML="<h1>Please open site in google chroeme</h1>";
		document.body.style.Background="#323232";
		document.body.style.color = "#fff";
	}

	else{
		document.getElementById("webpage").style.display ="block";
	}
	
}

checkBrowser();

// End broswer compitable