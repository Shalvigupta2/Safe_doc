// Side bar show hide coding 
function slidebar(){
	var sidebar = document.getElementById("side-bar");
	sidebar.style.display = "block";
	sidebar.style.animation = "sidebar 0.2s";
	sidebar.style.animationFillMode = "forwards";
}

function sidebarClose(){
	document.getElementById("side-bar").style.display = "none";
}