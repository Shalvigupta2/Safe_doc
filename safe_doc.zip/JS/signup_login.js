// Start signUp coding 
function signup(){
	var name = btoa(document.getElementById("name").value) ;
	var email = btoa(document.getElementById("email").value);
	var password = btoa( document.getElementById("password").value);
	var number = btoa(document.getElementById("mobile").value);
	var user_input = {name:name,email:email,password:password,number:number};
	var user_data = JSON.stringify(user_input);
	if (name!="" && email!="" && password!="" && number!="") {
		localStorage.setItem(email,user_data);
		document.getElementById("signup_success").innerHTML="Sign up success !";
		var name = document.getElementById("name").value="";
		var email = document.getElementById("email").value="";
		var password = document.getElementById("password").value="";
		var number = document.getElementById("mobile").value="";
		setTimeout(function(){document.getElementById("signup_success").innerHTML=""},2000);
		return false;
	}
	
}


function user_existed(){
	var email= btoa(document.getElementById("email").value);
	if (localStorage.getItem(email)!=null) {
		document.getElementById("user_found").innerHTML="User already Existed";
		document.getElementById("password").disabled=true;
		document.getElementById("mobile").disabled=true;
		document.getElementById("sign_up").disabled=true;
		document.getElementById("email").onclick=function(){
			this.value="";
			document.getElementById("user_found").innerHTML="";
			document.getElementById("password").disabled=false;
			document.getElementById("mobile").disabled=false;
			document.getElementById("sign_up").disabled=false;

		}
	}
}

// End sign Up coding

//Login coding 

function login(){
	var username = btoa(document.getElementById("login_user").value);
	var password = btoa(document.getElementById("login_pass").value);
	var user_input = {username:username,password:password};
	var user_data = JSON.stringify(user_input);
	sessionStorage.setItem(username,user_data);
	var session_data = sessionStorage.getItem(username);
	var user_detail = JSON.parse(session_data);
	if (localStorage.getItem(user_detail.username)==null) {
		alert("user not found");
	}

	else{
		var final_password =localStorage.getItem(user_detail.username);
		var extract_pass = JSON.parse(final_password);
		if (extract_pass.password==user_detail.password) {
		
			sessionStorage.setItem('user_mail',username);
	
			// location.replace("profile/profile.html");
			window.open("profile/profile.html");
		}

		else{
			alert("password not match");
		}
	}
} 
