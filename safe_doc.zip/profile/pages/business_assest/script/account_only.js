
 // set unit of mesure........
 function unit_of_mesure(){
    var unit_btn = document.getElementById("unit-mesure");
    var prim_con = document.getElementById("primary_content");
    var sec_con = document.getElementById("secondary_content");
    var close_icon = document.getElementById("close");
    var form = document.getElementById("unit-form");
    unit_btn.onclick=function(){
    	this.style.transform = "rotateX(180deg)";
    	this.style.transition ="1s";
    	setTimeout(function(){
    		prim_con.style.display = "none";
    		sec_con.style.display = "block";
    		sec_con.style.transform = "rotateX(-180deg)";
    		close_icon.onclick=function(){
    			unit_btn.className = "animated flipInX";
    			unit_btn.innerHTML="<i class='fa fa-balance-scale' style='sfont-size:25px;float:left'></i>Unit of Mesure";
    		
    		}
    			form.onsubmit=function(){
    					var input = sec_con.getElementsByTagName("INPUT");
    					var symbol = input[0].value;
    					var formal_name = input[1].value;
    					var unit_obj = {symbol:symbol,formal_name:formal_name};
    					var unit_detail =JSON.stringify(unit_obj);
    					localStorage.setItem("unit_mesure_"+symbol,unit_detail);
    					var success = document.createElement("DIV");
    					success.append(document.createTextNode("Success"));
    					success.style.color = "red";
    					success.style.float="left";
    					success.transform = "rotateX(-180deg)";
    					setTimeout(function(){success.innerHTML=""},1000);
    					unit_btn.append(success);
    					this.reset();
    					return false;
   				 }
    	},500)
    }

 }

 unit_of_mesure();
// sales voucher coding................
function sales_voucher(){
	var i;
	var sales_voucher_btn = document.getElementById("sales-voucher");
	var sales_voucher = document.getElementById("sales_voucher");
	sales_voucher_btn.onclick=function(){
		sales_voucher.style.display = "block";
		sales_voucher.className="animated slideInDown";
		document.getElementById("manage_section").style.display = "none";
		
		// showing tax from local storage............
		var tax_display = document.getElementById("tax_col");
		for(i=0;i<localStorage.length;i++){
			var tax_name = localStorage.key(i);
			if (tax_name.indexOf("tax")!= -1) {
				var tax_item = localStorage.getItem(tax_name);
				var extract = JSON.parse(tax_item);
				tax_display.innerHTML += extract.nameof_tax+" ("+extract.tax_qty+")"+"<br><br>";
				var subtotal = document.getElementById("subtotal").innerHTML;
				document.getElementById("tax_calculation").innerHTML+= subtotal+"<br><br>"; 
			}

		}
		//showing voucher number................
		var j;
		for(j=0;j<localStorage.length;j++){
			var all_keys = localStorage.key(j);
			if (all_keys.match("voucher_no")) {
				var voucher_no = all_keys.split("_");
				all_voucher_no = voucher_no[2];
				all_voucher_no++;
				document.getElementById("voucher-number").innerHTML=all_voucher_no;
			}
			else if (all_keys.match("voucher_no")==null) {
				document.getElementById("voucher-number").innerHTML=all_voucher_no;
			}
		}
		
		var sales_form = document.getElementById("form");
		var input = sales_form.getElementsByTagName("INPUT");
		input[0].focus();
		
		input[0].onkeyup=function(event){
			if (event.keyCode==13) {
				input[1].focus();
			}
			
		}
		input[1].onkeyup=function(event){
			if (event.keyCode==13) {
				input[2].focus();
			}
			
		}
		input[2].onkeyup=function(event){
			if (event.keyCode==13) {
				input[3].focus();
			}
			
		}
		input[3].onkeyup=function(event){
			if (event.keyCode==13) {
				document.getElementById("add_product").click();
				document.getElementById("items").focus();
			}
		}
	}
}

sales_voucher();

// close voucher...........

function close_invoice(){
	var close_invoice = document.getElementById("close_voucher_btn");
	close_invoice.onclick=function(){
	var sales_voucher = document.getElementById("sales_voucher");
	sales_voucher.className="animated slideOutUp";
	document.getElementById("manage_section").style.display = "block";
	}
}

close_invoice();

// showing voucher details and logo...........

function voucher_logo_details(){
	var voucher_logo = document.getElementById("voucher-logo");
	voucher_logo.src = localStorage.getItem("company_log");
	voucher_logo.backgroundSize = "cover";
	var voucher_details = document.getElementById("voucher_details");
	var string = localStorage.getItem("company");
	var company_details = JSON.parse(string);
	voucher_details.innerHTML="<div style='font-size:35px;text-transform:capitalize;font-family:Righteous;font-weight:bold'>"+company_details.cmp_name+"</div><address style='line-height:30px;'>Venue : "+company_details.address+"<br>Call : "+company_details.phone_number+"</address>";
}
 
voucher_logo_details();

 // Show profile pic coding.............
function profile_pic_show(){
	var pic = localStorage.getItem(sessionStorage.getItem("user_mail")+"images_url");
	var profile_pic = document.getElementById("pic_box");
	profile_pic.style.background = "url("+pic+")";
	profile_pic.style.backgroundSize = "cover";

}

profile_pic_show();

// end show profile pic coding...........


// add product item coding........
var store_subtotal,store_tax=[],store_total,store_paid,store_balace,all_voucher_no=1;
function add_item(){
	var product_table = document.getElementById("product_table");
	var tr = document.createElement("TR");
	var td_item = document.createElement("TD");
	var td_price = document.createElement("TD");
	var td_qty = document.createElement("TD");
	var td_unit = document.createElement("TD");
	var td_amount = document.createElement("TD");
	var td_delete = document.createElement("TD");
	var input_item = document.createElement("INPUT");
		input_item.type="text";
		input_item.placeholder="Item Description";
		input_item.className="item";
		input_item.id="items";
	var input_price = document.createElement("INPUT");
		input_price.type="number";
		input_price.placeholder="0.00";
		input_price.disabled=true;
		input_price.className="price";
	var input_qty = document.createElement("INPUT");
		input_qty.type="number";
		input_qty.placeholder="1";
		input_qty.disabled=true;
		input_qty.className="qty";
	var input_unit = document.createElement("SELECT");
		input_unit.className="unit";
		input_unit.id="unit";
		var u;
		for(u=0;u<localStorage.length;u++){
			var all_keys = localStorage.key(u);
			if (all_keys.match("unit_mesure")) {
				var unit_string = localStorage.getItem(all_keys);
				var unit_detail = JSON.parse(unit_string);
				var option = document.createElement("OPTION");
				option.append(document.createTextNode(unit_detail.symbol));
				input_unit.append(option);
			}
		}
	var input_amount = document.createElement("INPUT");
		input_amount.type="number";
		input_amount.placehoder="0.00";
		input_amount.className="amount";
	var del_icon = document.createElement("I");
		del_icon.className="fa fa-trash";
		del_icon.id = "delete-row";
		product_table.appendChild(tr);
		tr.append(td_item);
		tr.append(td_price);
		tr.append(td_qty);
		tr.append(td_unit);
		tr.append(td_amount);
		tr.append(td_delete);
		td_item.append(input_item);
		td_price.appendChild(input_price);
		td_qty.append(input_qty);
		td_unit.append(input_unit);
		td_amount.append(input_amount);
		td_delete.append(del_icon);
		td_delete.align="center";
		del_icon.onclick=function(){
			var del_iocn_td = this.parentElement;
			var remove_element = del_iocn_td.parentElement;
			remove_element.remove();
		}
		input_amount.onkeydown=function(){
			return false;
		}
		input_amount.oncontextmenu=function(){
			return false;
		}
		input_item.oninput=function(){
			this.onkeyup=function(event){
				if (event.keyCode==13) {
					var item_parent = this.parentElement;
					var tr_item = item_parent.parentElement;
					tr_item.getElementsByTagName("INPUT")[1].focus();
				}
			}
			input_price.disabled=false;
			input_price.oninput=function(){
				this.onkeyup=function(event){
				if (event.keyCode==13) {
					var item_parent = this.parentElement;
					var tr_item = item_parent.parentElement;
					tr_item.getElementsByTagName("INPUT")[2].focus();
				}
			}
				input_qty.disabled=false;
				input_qty.oninput=function(){
					input_amount.value= input_price.value*input_qty.value;
					var amount_input = document.getElementsByClassName("amount");
					var i;
					var previous_amount = 0;
					for(i=0;i<amount_input.length;i++){
						subtotal = previous_amount= previous_amount + Number(amount_input[i].value);
						store_subtotal=previous_amount.toFixed(2);
						document.getElementById("subtotal").innerHTML= "<i class='fa fa-rupee'></i> "+previous_amount.toFixed(2);
					}
					var reserve = 0 ;
					for(i=0;i<localStorage.length;i++){
						var tax_key = localStorage.key(i);
						if (tax_key.indexOf("tax")!= -1) {
							var tax_items = localStorage.getItem(tax_key);
							var extract = JSON.parse(tax_items);
					
							reserve = reserve+extract.tax_qty+"<br>";
							document.getElementById("tax_calculation").innerHTML="<span id='percentage' style='display:none;'>"+reserve.replace(0,"")+"</span>";
							
						}
						
					}
					
					var split_num = document.getElementById("percentage").innerHTML;
					var final_num = split_num.split("%<br>");
					for(i=0;i<final_num.length-1;i++){
						var fixed = (previous_amount*final_num[i])/100;
						store_tax[i]=fixed.toFixed(2);
						document.getElementById("tax_calculation").innerHTML+="<i class='fa fa-rupee'></i> "+fixed.toFixed(2)+"<br><br>";
						previous_amount=previous_amount+fixed;
						store_total=previous_amount;
						document.getElementById("total").innerHTML="<i class='fa fa-rupee'></i> "+ previous_amount;
						document.getElementById("due").innerHTML= "<i class='fa fa-rupee'></i> "+ previous_amount;

						var paid = document.getElementById("paid");
						paid.oninput=function(){
							document.getElementById("get_bill").style.display = "block";
							store_paid=this.value;
							store_balace=previous_amount-this.value;
							var dues = previous_amount-this.value;
							document.getElementById("due").innerHTML="<i class='fa fa-rupee'></i>"+dues;
						}
						
					}
					input_qty.onkeyup=function(event){
						if (event.keyCode==13) {
							document.getElementById("add_product").click();
							var items = document.getElementsByClassName("item");
							items[items.length-1].focus();
						}
					}
				}
				
			}
		}

}
document.getElementById("add_product").onclick=function(){
	add_item();
}

// showing date.......
var voucher_date;
function show_date(){
	var date = new Date();
	var current_date = date.getDate();
	var month = date.getMonth();
	var year = date.getFullYear();
	month++;
	document.getElementById("date").innerHTML += current_date+"/"+month+"/"+year;
	voucher_date =  current_date+"/"+month+"/"+year;
}

show_date();
// end showing date coding...........

// tax setup...........
 function tax_setup(){
 	var tax_btn = document.getElementById("tax_btn");
 	var tax_link = document.getElementById("tax_link");
 	tax_link.onclick=function(){
 		if (tax_btn.offsetHeight==60) {
 			tax_btn.style.height = "255px";
 			tax_btn.style.wbkitTransition = "0.5s";
 			tax_btn.style.transition = "0.5s";
 			document.getElementById("manage_section").style.display = "none";
 		}
 		else{
 			tax_btn.style.height = "60px";
 			tax_btn.style.wbkitTransition = "0.5s";
 			tax_btn.style.transition = "0.5s";
 			document.getElementById("manage_section").style.display = "block";
 		}
 		var tax_name = document.getElementById("tax_name");
 		var tax = document.getElementById("tax");
 		tax_name.onchange=function(){
 			if (this.value.indexOf("tax")!=-1) {
 				
 				tax.oninput=function(){
 					if (this.value.charAt(0).indexOf("%")==-1) {
 							var tax_form = document.getElementById("tax_form");
 							tax_form.onsubmit=function(){
 								if (tax.value.indexOf("%")!= -1) {
 									var regexp = /[a-z!=@#+$_^&*({;:"'|\][?/<,.>})-]/i;
 									var check = tax.value.match(regexp);
 									if (check == null) {
 										var nameof_tax = document.getElementById("tax_name").value;
 										var tax_qty = document.getElementById("tax").value;
 										var tax_detail = {nameof_tax:nameof_tax,tax_qty:tax_qty};
 										var tax_string = JSON.stringify(tax_detail);
 										localStorage.setItem(nameof_tax,tax_string);
 							
 									}
 									else{
 										alert("0 to 9 amd % symobol allowed in tax -field");
 										return false;
 									}
 								}
 								else{
 									alert("must add % symbol in tax field");
 									return false;
 								}
 							}
 					}
 					else{
 						this.className="animated infinite pulse";
 						this.style.color = "red";
 						this.style.borderColor = "red";
 						this.value = " % not allowed at first place";
 						this.onclick =function(){
 						this.className="";
 						this.style.color = "";
 						this.style.borderColor = "";
 						this.value = " ";
 						}
 					}
 				}
 			}
 			else{
 				this.className="animated infinite pulse";
 				this.style.color = "red";
 				this.style.borderColor = "red";
 				this.value = "ples add tax ";
 				this.onclick=function(){
 				this.className="";
 				this.style.color = "";
 				this.style.borderColor = "";
 				this.value = "";
 				}
 			}
 		}
 		
 	}
 }
tax_setup();
 // show company log ...........

 function show_company_log(){
 	var logo = document.getElementById("brand");
 	var logo_name = localStorage.getItem("company_log");
 	logo.style.backgroundImage = "url("+logo_name+")";
 	logo.style.backgroundSize = "cover";
 }

 show_company_log();

 // show company name coding..........
 function show_brand_name(){
 	var brand_name = document.getElementById("brand_name");
 	var company_details = localStorage.getItem("company");
 	var cmp_data = JSON.parse(company_details);
 	brand_name.innerHTML=cmp_data.cmp_name;
 	// alert(cmp_data.cmp_name);
 }

 show_brand_name();

 // get bill 
function get_bill(){
	var bill = document.getElementById("get_bill")
 	bill.onclick=function(){
 		var i,store_item=[],store_price=[],store_qty=[],store_unit=[],store_amount=[];
 		// var remove_item = document.getElementsByClassName("print_remove");
 		// for(i=0;remove_item.length;i++){
 		// 	remove_item[i].remove();
 		// }
 		document.getElementById("close_voucher_btn").style.display = "none";
 		var sales_voucher = document.getElementById("sales_voucher");
 		sales_voucher.style.width = "100%";
 		sales_voucher.style.left = "0";
 		sales_voucher.style.top="0";
 		document.getElementById("calculation_table").border = "1";
 		var get_bill_td = this.parentElement;
 		var get_bill_tr = get_bill_td.parentElement;
 		get_bill_tr.remove();

 		var input = sales_voucher.getElementsByTagName("INPUT");
 		var select = document.getElementsByTagName("SELECT");
 		for(i=0;i<input.length;i++){
 			input[i].style.border = "none";
 			input[i].style.padding = "0";
 			input[i].style.background = "white";

 		}
 		for(i=0;i<select.length;i++){
 			select[i].style.border = "none";
 			select[i].style.webitAppearance="none";
 			select[i].style.mozAppearance="none";
 			select[i].style.appearance="none";
 		}

 		var product_table = document.getElementById("product_table");
 		product_table.border = "1";
 		var product_table_tr = product_table.getElementsByTagName("TR");
 		for(i=0;i<product_table_tr.length;i++){
 			product_table_td = product_table_tr[i].getElementsByTagName("TD");
 			product_table_td[product_table_td.length-1].style.display = "none";
 		}
 		document.getElementById("paid").style.border = "none";
 		document.getElementById("add_product").style.display = "none";
 		// voucher details storing coding...............

 		var buyer_name = document.getElementById("buyer-name").value;
 		var buyer_email = document.getElementById("buyer-email").value;
 		var buyer_address = document.getElementById("buyer-address").value;
 		var buyer_phone = document.getElementById("buyer-phone").value;
 		var buyer_item = document.getElementsByClassName("item");
 		for(i=0;i<buyer_item.length;i++){
 			store_item[i]=buyer_item[i].value;
 		}
 		var buyer_price = document.getElementsByClassName("price");
 		for(i=0;i<buyer_price.length;i++){
 			store_price[i]=buyer_price[i].value;
 		}
 		var buyer_qty = document.getElementsByClassName("qty");
 		for(i=0;i<buyer_qty.length;i++){
 			store_qty[i]=buyer_qty[i].value;
 		}
 		var buyer_unit = document.getElementsByClassName("unit");
 		for(i=0;i<buyer_unit.length;i++){
 			store_unit[i]=buyer_unit[i].value;
 		}
 		var buyer_amount = document.getElementsByClassName("amount");
 		for(i=0;i<buyer_amount.length;i++){ 
 			store_amount[i]=buyer_amount[i].value;
 		}
 
 		var buyer_object = {buyer_name:buyer_name,buyer_email:buyer_email,buyer_address:buyer_address,buyer_phone:buyer_phone,store_item:store_item,store_price:store_price,store_qty:store_qty,store_amount:store_amount,store_subtotal:store_subtotal,store_tax:store_tax,store_total:store_total,store_paid:store_paid,store_balace:store_balace,buyer_purchase_date:voucher_date,store_unit:store_unit};
 		var buyer_detials = JSON.stringify(buyer_object);
 		localStorage.setItem("voucher_no_"+all_voucher_no, buyer_detials);

 	}
}
 
 get_bill();

 // search voucher coding.................
 function serch_voucher(){
 	var serch_field = document.getElementById("serch-voucher");
 	serch_field.onkeyup=function(event){
 		if (event.keyCode==13) {
 			var user_input = "voucher_no_"+this.value;
 			var i;
 			for(i=0;i<localStorage.length;i++){
 				var all_keys = localStorage.key(i);
 				if (user_input==all_keys) {
 					document.getElementById("voucher-number").innerHTML=all_keys;
 					var buyer_string =localStorage.getItem(all_keys);
 					var buyer_extract = JSON.parse(buyer_string);
 					document.getElementById("delete_voucher_btn").style.display = "block";

 					var del_btn = document.getElementById("delete_voucher_btn");
 					del_btn.onclick=function(){
 						var allow = window.confirm("are you sure");
 						if (allow==true) {
 							localStorage.removeItem("voucher_no_"+serch_field.value);
 							window.location=location.href;
 						}
 						
 					}
 					document.getElementById("sales-voucher").click();
 					document.getElementById("voucher-number").innerHTML=all_keys;
 					document.getElementById("buyer-name").value=buyer_extract.buyer_name;
 					document.getElementById("buyer-email").value=buyer_extract.buyer_email;
 					document.getElementById("buyer-address").value=buyer_extract.buyer_address;
					document.getElementById("buyer-phone").value=buyer_extract.buyer_phone;
					var item= document.getElementsByClassName("item");
					var price = document.getElementsByClassName("price");
					var qty = document.getElementsByClassName("qty");
					var amount = document.getElementsByClassName("amount");
					var item_length = buyer_extract.store_item.length;
 					var j;
 					for(j=0;j<item_length;j++){
 						document.getElementById("add_product").click();
 						item[j].value=buyer_extract.store_item[j];
 						price[j].value=buyer_extract.store_price[j];
 						qty[j].value=buyer_extract.store_qty[j];
 						amount[j].value=buyer_extract.store_amount[j];
 					}
 					document.getElementById("subtotal").innerHTML= buyer_extract.store_subtotal;
 					var tax_length = buyer_extract.store_tax.length;
 					document.getElementById("tax_calculation").innerHTML="";
 					for(j=0;j<tax_length;j++){
 						document.getElementById("tax_calculation").innerHTML+=buyer_extract.store_tax[j]+"<br>";
 						
 					}
 					document.getElementById("total").innerHTML= buyer_extract.store_total;
 					document.getElementById("paid").value= buyer_extract.store_paid;
 					document.getElementById("due").innerHTML= buyer_extract.store_balace;


 				}
 			}
 				// showing date in voucher....
 				var date = document.getElementById("date");
 					date.innerHTML=buyer_extract.buyer_purchase_date;
 					date.onclick=function(){
 						var input = window.prompt("change date",buyer_extract.buyer_purchase_date);
 						this.innerHTML=input;
 						voucher_date =input;
 						if (input==null) {
 							this.innerHTML=buyer_extract.buyer_purchase_date;
 						}
 					}
 			
 		}
 	}
 }

 serch_voucher();

 // showing manage voucher
 function showing_voucher(){
 	var i;
 	for(i=0;i<localStorage.length;i++){
 		var all_keys = localStorage.key(i);
 		if (all_keys.indexOf("voucher_no")!= -1) {

 			document.getElementById("manage_voucher").style.display = "block";
 			return false;
 		}
 		else{
 			document.getElementById("manage_voucher").style.display = "none";

 		}
 	}
 }

 showing_voucher();

 // manage tax................
 function manage_tax(){
 	var manage_tax = document.getElementById("select_tax");
	var i;
 		for(i=0;i<localStorage.length;i++){
 			var all_keys = localStorage.key(i);
 			if (all_keys.match("tax")) {
 				document.getElementById("manage_tax").style.display = "block";
 				var option = document.createElement("OPTION");
 				option.append(document.createTextNode(all_keys));
 				manage_tax.append(option);
 			}
 		}
// open tax details in tax setup .............

manage_tax.onchange=function(){
		var reserve=this.value;
 		document.getElementById("tax_link").click();

 		manage_tax.onclick=function(){
 			document.getElementById("tax_link").click();
 		}
 		var tax_icon = document.getElementById("tax_icon");
 		tax_icon.className="fa fa-trash";
 		tax_icon.onclick=function(){
 			var del = window.confirm("are you sure delete tax");
 			if (del==true) {
 				
 				localStorage.removeItem(reserve);
 				window.location=location.href;
 			}
 			
 		}
 		var tax_string = localStorage.getItem(this.value);
 		var tax_extract = JSON.parse(tax_string);
 		document.getElementById("tax_name").value=tax_extract.nameof_tax;
 		document.getElementById("tax").value=tax_extract.tax_qty;
 		document.getElementById("tax_form").onsubmit=function(){
 			var nameof_tax = document.getElementById("tax_name").value;
 			var tax_qty = document.getElementById("tax").value;
 			if (nameof_tax==reserve) {
 				var tax_object = {nameof_tax:nameof_tax,tax_qty:tax_qty};
 				var tax_store = JSON.stringify(tax_object);
 				localStorage.setItem(nameof_tax,tax_store);
 			}
 			else{
 				localStorage.removeItem(reserve);
 				var tax_object = {nameof_tax:nameof_tax,tax_qty:tax_qty};
 				var tax_store = JSON.stringify(tax_object);
 				localStorage.setItem(nameof_tax,tax_store);
 			}
 			
 		}
 	}
	
 }

 manage_tax();

 // shut company coding................
  function shut_company(){
  	shut_cmp = document.getElementById("shut-company");
  	shut_cmp.onclick=function(){
  		window.location="../business.html";
  	}
  }
 
 shut_company();
