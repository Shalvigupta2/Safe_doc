// tabs
function tabs(){
	var tab_list = document.getElementById("tab_list");
	var button = tab_list.getElementsByTagName("BUTTON");
	var hide = document.getElementsByClassName("open");
	var i;
	var j;
	for(i=0;i<button.length;i++){
		button[i].onclick=function(){
			
			for(j=0;j<hide.length;j++){
				hide[j].style.display ="none";
			}
			for(j=0;j<button.length;j++){
				button[j].className="";
			}
			var id_value = this.innerHTML.toLowerCase();
			var show_element = document.getElementById(id_value);
			show_element.style.display = "block";
			var input = show_element.getElementsByTagName("INPUT");
			input[0].focus();
			this.className="active fade";
		}
	}
	document.getElementById("default").click();
}
tabs();

// update cr and dr.............
function update_cr_dr(){
	var group = document.getElementById("group");
	group.onchange=function(){
	var ac = this.value;
	var mode = document.getElementById("mode");
		switch (ac) {
			case "Capital Account":mode.value="Cr";
				break;
			case "Sales Account":mode.value="Cr";
				break;
			case "Purchase Account":mode.value="Dr";
				break;
			case "Sundary Creditors":mode.value="Cr";
				break;
			case "Sundary Debitors":mode.value="Dr";
				break;
			default:mode.value="";
				
				break;
		}
	}
}

update_cr_dr();
// create form submit............
function create_submit(){
	var create_form = document.getElementById("create_form");
	var group = document.getElementById("group");
	create_form.onsubmit = function(){
		if (group.value!="Select Group") {
			var ledger_name = document.getElementById("ledger_name").value;
			var balance = document.getElementById("balance").value;
			var mode = document.getElementById("mode").value;
			var maling_name = document.getElementById("maling_name").value;
			var address = document.getElementById("address").value;
			var ledger_details = {ledger_name:ledger_name,group:group.value,balance:balance,mode:mode,maling_name:maling_name,address:address};
			var ledger_store = JSON.stringify(ledger_details);
			localStorage.setItem("ledger_no_"+document.getElementById("ledger_no").innerHTML,ledger_store);

		}
		else{
			group.style.borderColor = "red";
			group.className = "animated infinite pulse";
			group.onclick = function(){
				group.style.borderColor = "";
				group.className = "";
			}
			return false;
		}
	}


}
create_submit();
// update ledger no..........
function update_ledger_no(){
	var i,large_no=1;
	for(i=0;i<localStorage.length;i++){
		 var all_keys = localStorage.key(i);
		 if (all_keys.match("ledger_no")!=null) {
			 var no = all_keys.split("_" );
			 var final_no = Number(no[2])+1;
			 if(final_no>large_no)
			 {
			 	large_no = final_no;


			 }
		}
	}
	document.getElementById("ledger_no").innerHTML=large_no;
}

update_ledger_no();

// total calculation......................
function total_cal(){
	var i,debit=0,credit=0,diff=0;
	for(i=0;i<localStorage.length;i++){
		var all_keys = localStorage.key(i);
		if (all_keys.match("ledger_no")!=null) {
			var ledger_data = localStorage.getItem(all_keys);
			var ledger = JSON.parse(ledger_data);
			if (ledger.mode.match("Cr")!=null) {
				credit += Number(ledger.balance);
				document.getElementById("credit").innerHTML=credit+ " Cr"; 
			}
		 else{
		 		debit += Number(ledger.balance);
				document.getElementById("debit").innerHTML=debit+ " Dr"; 
		 }
		}
		if (credit>debit) {
			document.getElementById("diff").innerHTML= credit - debit+" Cr";
		}
		else{
			document.getElementById("diff").innerHTML = debit-credit+ " Dr";
		}
	}
}

total_cal();

// edit ledger coding...........
function edit_ledger(){
	var ledger_number = document.getElementById("edit_ledger");
	ledger_number.onkeyup=function(event){
		if (event.keyCode==13) {
			if (this.value=="") {
				alert("please ente ledger number");
			}
			else{
				var ledger_no = localStorage.getItem("ledger_no_"+this.value);
				if (ledger_no==null) {
					document.getElementById("ledger_notice").innerHTML="<i class='fa fa-times-circle' style='font-size: 30px;color: red;'></i> Ledger not found !";
					document.getElementById("edit_table").style.display = "none";
					document.getElementById("edit-lnum").innerHTML="";
					document.getElementById("edit-lname").innerHTML="";
					document.getElementById("edit-balance").innerHTML="";
					document.getElementById("edit-mname").innerHTML = "";
					document.getElementById("edit-address").innerHTML ="";
					document.getElementById("edit-group").style.display = "none";

				}
				else {
					
					var ledger_data = localStorage.getItem("ledger_no_"+this.value);
					var ledger = JSON.parse(ledger_data);
					if (ledger.delete_mode!="active") {
					document.getElementById("edit-lnum").innerHTML=ledger_number.value;
					document.getElementById("edit-lname").innerHTML="<span id='current-lname' contenteditable='true'>"+ledger.ledger_name+"</span>";
					document.getElementById("edit-group").style.display="block";
					var current_group = document.getElementById("edit-group");
					current_group.value=ledger.group;
					current_group.onchange=function(){
						var ac = this.value;
						var current_mode = document.getElementById("current-mode");
						switch(ac){
							case "Capital Account":current_mode.innerHTML="Cr";
							break;

							case "Sales Account":current_mode.innerHTML="Cr";
							break;

							case "Purchase Account":current_mode.innerHTML="Dr";
							break;

							case "Sundary Creditors":current_mode.innerHTML="Cr";
							break;

							case "Sundary Debitors":current_mode.innerHTML="Dr";
							break;

							default:current_mode.innerHTML="";
							break;

						}
					}
					document.getElementById("edit_table").style.display = "block";
					document.getElementById("edit-balance").innerHTML = "<span id='current-balance' contenteditable='true'>"+ledger.balance+"</span> <span id='current-mode' contenteditable='true' >"+ledger.mode+"</span>";
					document.getElementById("edit-mname").innerHTML = ledger.maling_name=="" || ledger.maling_name==undefined ? " ":"<span id='current-mlname' contenteditable='true'>"+ledger.maling_name+"</span>";
					document.getElementById("edit-address").innerHTML =ledger.address=="" || ledger.address==undefined ?" ":"<span contenteditable='true' id='current-address'>"+ledger.address+"</span>";
					document.getElementById("ledger_notice").innerHTML="";


					// save ledger coding...........
					var save_btn = document.getElementById("save");
					save_btn.onclick=function(){
						var final_data = {
							ledger_name:document.getElementById("current-lname").innerHTML,
							group:current_group.value,
							balance:document.getElementById("current-balance").innerHTML,
							mode:document.getElementById("current-mode").innerHTML,
							maling_name:document.getElementById("current-mlname").innerHTML,
							address:document.getElementById("current-address").innerHTML
						};
						var store_ledger = JSON.stringify(final_data);
						localStorage.setItem("ledger_no_"+ledger_number.value, store_ledger);
						
					}
					// delete ledger coding..........
					var del = document.getElementById("delete");
					del.onclick=function(){
						var check = window.confirm("are you sure to delete");
						if (check==true) {
						final_data = {
							ledger_name:document.getElementById("current-lname").innerHTML,
							group:current_group.value,
							balance:document.getElementById("current-balance").innerHTML,
							mode:document.getElementById("current-mode").innerHTML,
							maling_name:document.getElementById("current-mlname")== null ? "":document.getElementById("current-mlname").innerHTML,
							address:document.getElementById("current-address")== null ? "":document.getElementById("current-address").innerHTML,
							delete_mode:"active"
							};
							var current_data = JSON.stringify(final_data);
							localStorage.setItem("ledger_no_"+ledger_number.value, current_data);
							window.location=location.href;
						}
					}

					}
					else{
						document.getElementById("ledger_notice").innerHTML="whoops ledger deleted some time ageo <button id='restore'>Restore Ledger</button>";
						document.getElementById("restore").onclick=function(){
							
							var take_data = localStorage.getItem("ledger_no_"+ledger_number.value);
							localStorage.setItem("ledger_no_"+ledger_number.value,take_data.replace("active","deactive"));
							window.location=location.href;
						}
					}
				}
			}
		}
	}
}

edit_ledger();

// search ledger coding.............
function search_ledger(){
	var search = document.getElementById("search_btn");
	search.onkeyup=function(event){
		if (event.keyCode==13) {
			if (this.value!="") {
				var ledger_no = localStorage.getItem("ledger_no_"+this.value);
				if (ledger_no!=null) {
					document.getElementById("search_table").style.display = "block";
					var ledger_data = localStorage.getItem("ledger_no_"+this.value);
					var ledger_extract = JSON.parse(ledger_data);
					document.getElementById("s-lnum").innerHTML=this.value;
					document.getElementById("s-lname").innerHTML=ledger_extract.ledger_name;
					document.getElementById("s-group").innerHTML=ledger_extract.group;
					document.getElementById("s-mlname").innerHTML=ledger_extract.maling_name;
					document.getElementById("s-address").innerHTML=ledger_extract.address;
					document.getElementById("s-balance").innerHTML=ledger_extract.balance+" "+ledger_extract.mode;
				}
				else{
					window.alert("ledger not found");
				}
				


			}
			else{
				alert("please enter ledger number !");
			}
		}
	}
}

search_ledger();
