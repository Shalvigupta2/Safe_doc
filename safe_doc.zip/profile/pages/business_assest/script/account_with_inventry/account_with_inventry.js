// show time and date...........
function date_time(){
	var current_date = new Date;
	var d = current_date.getDate();
	var m = current_date.getMonth();
	var y = current_date.getFullYear();
	document.getElementById("date").innerHTML="Date : "+d+" - "+ parseInt( m+1)+" - "+y;
	document.getElementById("time").innerHTML = "Time : "+ current_date.toLocaleTimeString();

}
date_time();
// showing profile pic...........
function show_profile_pic(){
	var pic_box = document.getElementById("pic_box");
	var image_name = localStorage.getItem(sessionStorage.getItem("user_mail")+"images_url");
	pic_box.style.background = "url("+image_name+")";
	pic_box.style.backgroundSize = "cover";
}

show_profile_pic();

// showing company log and name.........
function show_company_log(){
	var logo_name = localStorage.getItem("company_log");
	var logo_box = document.getElementById("logo");
	logo_box.style.background = "url("+logo_name+")";
	logo_box.style.backgroundSize = "cover";
	logo_box.style.backgroundRepeat = 'no-repeat';
	logo_box.style.webkitBackgroundClip = "content-box";
	// show company name........
	var cmp_string = localStorage.getItem("company");
	var cmp_extract = JSON.parse(cmp_string);
	document.getElementById("cmp_name").innerHTML=cmp_extract.cmp_name;

}
show_company_log();

function app_box(){
	var icon = document.getElementById("app_box");
	var li = icon.getElementsByTagName("LI");
	var i;
	for(i=0;i<li.length;i++){

	   li[i].onmouseover=function(){

	   		this.style.transform="rotate(360deg)";
	   		this.style.transition = "0.5s";
	   		this.onmouseout=function(){
	   			this.style.transform="rotate(0deg)";
	   			this.style.transition = "0.5s";
	   		}	
	}
}

}

app_box();

// exit company coding............
function exit_company(){
	var exit = document.getElementById("exit");
	exit.onclick=function(){
		history.back();
	}

}

exit_company();

// update default ledeger......................

function default_ledger(){
	var cash = localStorage.getItem("cash_ledger");
	var profit_loss = localStorage.getItem("profit_loss_ledger");
	if (cash==null && profit_loss==null) {
		var cash_ledger = {ledger_name:"Cash",group:"Cash in hand",balance:"",mode:""};
		var cash_store = JSON.stringify(cash_ledger);
		localStorage.setItem("cash_ledger",cash_store);

		var profit_loss_ledger = {ledger_name:"Profit & Loss A/c",group:"Profit & Loss A/c",balance:"",mode:""};
		var profit_loss_store = JSON.stringify(profit_loss_ledger);
		localStorage.setItem("profit_loss_ledger",profit_loss_store);
	}
	
}

default_ledger();