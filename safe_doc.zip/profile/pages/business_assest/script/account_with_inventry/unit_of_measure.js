// unit of measure coding.........
function unit_of_measure(){
	var frame = document.getElementById("frame");
	var unit_btn = document.getElementById("unit");
	unit_btn.onclick=function(){
		frame.style.display = "block";
		frame.src = "accounts_only.html#unit-mesure";
		frame.onload=function(){
			var target = frame.contentWindow.document.getElementById('unit-mesure');
			target.style.position = 'absolute';
			target.style.left = "0";
			target.click();
			this.contentWindow.document.getElementById("close").style.display = "none";
			var close_btn = document.createElement("I");
			close_btn.className="fa fa-close";
			close_btn.style.float = 'right';
			target.append(close_btn); 
			close_btn.onclick=function(){
				frame.style.display = "none";
				setTimeout(function(){window.location=location.href},100);
			}
			this.contentWindow.document.getElementById("edit_unit_mesure").style.display = "block";
			var select_group = this.contentWindow.document.getElementById("select_unit_mesure");
			select_group.style.display = "block";
			var i;
			for(i=0;i<localStorage.length;i++){
				var all_keys = localStorage.key(i);
				if (all_keys.match("unit_mesure")) {
					var unit_string = localStorage.getItem(all_keys);
					var unit_extract = JSON.parse(unit_string);
					var option = document.createElement("OPTION");
					option.append(document.createTextNode(unit_extract.symbol));
					select_group.append(option);
				}
			}
			select_group.onchange=function(){
				var del_icon = frame.contentWindow.document.getElementById("del_icon");
				del_icon.style.display = "block";
				del_icon.onclick=function(){
					var choice = window.confirm("Do you want to delete !");
					if (choice==true) {
						localStorage.removeItem("unit_mesure_"+select_group.value);
						window.location=location.href;
					}	
				}
				var input = frame.contentWindow.document.getElementsByTagName("INPUT");
				var save_data = localStorage.getItem("unit_mesure_"+this.value);
				var extract_data = JSON.parse(save_data);
				input[0].value = extract_data.symbol;
				input[1].value = extract_data.formal_name;
				input[2].type = "button";
				input[2].id = "s_btn";
				input[2].onclick=function(){
					if (input[0].value==select_group.value) {
						var save = {symbol:input[0].value,formal_name:input[1].value};
						var store = JSON.stringify(save);
						localStorage.setItem("unit_mesure_"+input[0].value, store);
						var success = document.createElement("DIV");
						success.append(document.createTextNode("success"));
						success.style.color = "red";
						success.transform="rotateX(-180deg)";
						target.append(success);
						setTimeout(function(){window.location=location.href},1000);

					}
					else{
						localStorage.removeItem("unit_mesure_"+select_group.value);
						var save = {symbol:input[0].value,formal_name:input[1].value};
						var store = JSON.stringify(save);
						localStorage.setItem("unit_mesure_"+input[0].value, store);
						var success = document.createElement("DIV");
						success.append(document.createTextNode("success"));
						success.style.color = "red";
						success.transform="rotateX(-180deg)";
						target.append(success);
						setTimeout(function(){window.location=location.href},1000);
					}
				}
			}
		}
	}
}
unit_of_measure();