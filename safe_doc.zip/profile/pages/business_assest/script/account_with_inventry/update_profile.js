// show time and date...........
function date_time(){
	var current_date = new Date;
	var d = current_date.getDate();
	var m = current_date.getMonth();
	var y = current_date.getFullYear();
	document.getElementById("date").innerHTML="Date : "+d+" - "+ parseInt( m+1)+" - "+y;
	document.getElementById("time").innerHTML = "Time : "+ current_date.toLocaleTimeString();

}

date_time();
// showing profile pic...........
function show_profile_pic(){
	var pic_box = document.getElementById("pic_box");
	var image_name = localStorage.getItem(sessionStorage.getItem("user_mail")+"images_url");
	pic_box.style.background = "url("+image_name+")";
	pic_box.style.backgroundSize = "cover";
}

show_profile_pic();
// showing company log and name.........
function show_company_log(){
	var logo_name = localStorage.getItem("company_log");
	var logo_box = document.getElementById("cmp_logo");
	logo_box.style.background = "url("+logo_name+")";
	logo_box.style.backgroundSize = "cover";
	logo_box.style.backgroundRepeat = 'no-repeat';
	logo_box.style.webkitBackgroundClip = "content-box";
	// show company name........
	var cmp_string = localStorage.getItem("company");
	var cmp_extract = JSON.parse(cmp_string);
	document.getElementById("cmp_name").innerHTML=cmp_extract.cmp_name;

}
show_company_log();