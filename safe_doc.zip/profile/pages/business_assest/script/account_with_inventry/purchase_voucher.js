// display puchase account
function display_purchase_ac(){
	var input = document.getElementById("purchase_input");
	var i,j;
	input.onclick=function(){
		document.getElementById("purchase-hint").innerHTML="";
		for(i=0;i<localStorage.length;i++){
			var all_keys = localStorage.key(i);
			if (all_keys.match("ledger_no")) {
				var key_data = localStorage.getItem(all_keys);
				var main_data = JSON.parse(key_data);
				if (main_data.group.match("Purchase Account")) {
					var purchase_hint = document.getElementById("purchase-hint");
					purchase_hint.style.display = "block";
					purchase_hint.innerHTML += "<p class='hint-over'>"+main_data.ledger_name+"</p>";
					var hint_over = document.getElementsByClassName("hint-over");
					for(j=0;j<hint_over.length;j++){
						hint_over[j].onmouseover=function(){
							this.style.backgroundColor = "blue";
							this.style.color = "white";
							this.onclick=function(){
								input.value = this.innerHTML;
								document.getElementById("add-item").disabled=false;
								purchase_hint.style.display = "none";
								input.focus();
							}
						}
						hint_over[j].onmouseout=function(){
							this.style.backgroundColor = "";
							this.style.color = "";
						}
					}
				}	
			}
		}
	}
	input.oninput=function(){
		var hint_over = document.getElementsByClassName("hint-over");
		for(i=0;i<hint_over.length;i++){
			if (hint_over[i].innerHTML.toUpperCase().indexOf(input.value.toUpperCase())!= -1) {
				hint_over[i].style.display = "block";
			}
			else{
				hint_over[i].style.display = "none";
			}
		}
	}
	input.click();
	input.focus();
	// enter on purchase input 
	input.onkeyup=function(event){
		if (event.keyCode==13) {
			if (this.value!="") {
				var hint_over = document.getElementsByClassName("hint-over");
				for(i=0;i<hint_over.length;i++){
					if (this.value.toUpperCase()==hint_over[i].innerHTML.toUpperCase()) {
						add_items();
						document.getElementById("purchase-hint").style.display = "none";
					}
				}
			}
		}
	}
}
display_purchase_ac();

// add items coding..........
function add_items(){
	var item_table = document.getElementById("item-table");
	var tr = document.createElement("TR");
	item_table.append(tr);
	var item_td = document.createElement("TD");
	var qty_td = document.createElement("TD");
	var rate_td = document.createElement("TD");
	var per_td = document.createElement("TD");
	var sp_td = document.createElement("TD");
	var amt_td = document.createElement("TD");
	var delete_td = document.createElement("TD");
	tr.append(item_td);
	tr.append(qty_td);
	tr.append(rate_td);
	tr.append(sp_td);
	tr.append(per_td);
	tr.append(amt_td);
	tr.append(delete_td);
	var input_items = document.createElement("INPUT");
	input_items.type = "text";
	input_items.className = "input-items";
	input_items.placeholder = "laptop";
	var input_qty = document.createElement("INPUT");
	input_qty.type="number";
	input_qty.id = "input-qty";
	input_qty.className = "input-qty";
	input_qty.placeholder="00.00"
	input_qty.disabled = true;
	var input_rate = document.createElement("INPUT");
	input_rate.type="number";
	input_rate.id = "input-rate";
	input_rate.className = "input-rate";
	input_rate.placeholder="00.00";
	input_rate.disabled =true;
	input_sp = document.createElement("INPUT");
	input_sp.type="number";
	input_sp.id="input-sp";
	input_sp.className="input-sp";
	input_sp.placeholder="00.00";
	input_sp.disabled=true;
	var input_per = document.createElement("SELECT");
	var option = document.createElement("OPTION");
	option.append(document.createTextNode("Unit ?"));
	input_per.append(option);
	var i;
	for(i=0;i<localStorage.length;i++){
		var all_keys = localStorage.key(i);
		if (all_keys.match("unit_mesure")) {
			var key_data = localStorage.getItem(all_keys);
			var extract_data = JSON.parse(key_data);
			var option = document.createElement("OPTION");
			option.append(document.createTextNode(extract_data.symbol));
			input_per.append(option);
		}
	}
	var input_amt = document.createElement("INPUT");
	input_amt.type="number";
	input_amt.id = "input-amt";
	input_amt.className = "input-amt";
	input_amt.placeholder="00.00";
	input_amt.disabled = true;
	var del_icon = document.createElement("I");
	del_icon.className="fa fa-trash";
	item_td.append(input_items);
	qty_td.append(input_qty);
	rate_td.append(input_rate);
	sp_td.append(input_sp);
	per_td.append(input_per);
	amt_td.append(input_amt);
	delete_td.append(del_icon);
	// delete coding...........
	del_icon.onclick=function(){
		this.parentElement.parentElement.remove();
		subtotal();
		tax_calculation();
		calculate_total();
		if (item_table.getElementsByTagName("TR").length ==1) {
			document.getElementById("subtotal-amount").innerHTML=" 00.00";
			var taxes_amount = document.getElementById("taxes-amount");
			var p = taxes_amount.getElementsByTagName("P");
			var i;
			for(i=0;i<p.length;i++){
				p[i].innerHTML=" 00.00";
			}

			document.getElementById("calculated-total").innerHTML = " 00.00";
			document.getElementById("paid").value ="00.00";
			document.getElementById("calculated-dues").innerHTML=" 00.00";
		}
	}

	// enabling input field coding...........
	input_items.oninput=function(){
		input_qty.disabled = false;
		input_qty.oninput=function(){
			input_amt.value = input_qty.value*input_rate.value;
			subtotal();
			tax_calculation();
			calculate_total();
			input_rate.disabled = false;
			input_rate.onkeyup = function(event){
				input_sp.disabled=false;
				input_amt.disabled = false;
				input_amt.value = input_qty.value*input_rate.value;
				subtotal();
				tax_calculation();
				calculate_total();
				var key = String.fromCharCode(event.keyCode);
				var per_value = input_per.getElementsByTagName("OPTION");
				for(i=0;i<per_value.length;i++){
					if (per_value[i].value.toUpperCase().charAt(0).match(key.toUpperCase())) {
						input_per.value=per_value[i].value;
					}
				}
				input_amt.onkeydown=function(){
					return false;
				}

				input_amt.oncontextmenu = function(){
					return false;
				}
			}
		}
	}
	// active item fields...........
	var active_item = document.getElementsByClassName("input-items");
	active_item[active_item.length-1].focus();

	// on enter coding............
	input_items.onkeyup=function(event){
		if (event.keyCode==13) {
			input_qty.focus();
		}
	}

	input_qty.onkeyup=function(event){
		if (event.keyCode==13) {
			input_rate.focus();
		}
	}

	input_qty.onkeyup=function(event){
		if (event.keyCode==13) {
			input_rate.focus();
		}
	}

	input_rate.onkeydown=function(event){
		if (event.keyCode==13) {
			input_sp.focus();
		}
	}
	input_sp.onkeydown=function(event){
		if (event.keyCode==13) {
			input_per.focus();
			input_per.onchange=function(event){
			document.getElementById("add-item").disabled=false;
			document.getElementById("add-item").click();
		}
	}
}

}



// function add item add.........
function add_item_call(){
	document.getElementById("add-item").onclick=function(){
		add_items();
	}

	// add items shortcut keys.............

	window.onkeyup=function(event){
		if (event.altKey && event.keyCode==65) {
			add_items();
		}
	}
}

add_item_call();

// subtotal coding.....................

function subtotal(){
	var all_amt = document.getElementsByClassName("input-amt");
	var i,previous_data=0;
	for(i=0;i<all_amt.length;i++){
		previous_data += (Number(all_amt[i].value));
		document.getElementById("subtotal").innerHTML = "<p class ='fa fa-rupee' id='subtotal-amount'> "+previous_data.toFixed(2)+"</p>";
	}
}

subtotal();

// Tax setup............
function set_tax(){
	var tax_name = document.getElementById("tax-name");
	var tax_amount = document.getElementById("tax-amount");
	var tax_form = document.getElementById("tax-form")
	tax_name.onchange = function(){
		if (this.value.match(" tax")!= null) {

			tax_amount.oninput = function(){
				if (this.value.charAt(0).indexOf("%")== -1) {

					tax_form.onsubmit = function(){
						if (tax_amount.value.indexOf("%")!= -1) {
							
							var regexp = /[a-z!=@#+$^&*({;:"'|\]?/<,.>})-]/i;
							var check = tax_amount.value.match(regexp);
							if (check == null) {
								var tax_data = {tax_name:tax_name.value,tax:tax_amount.value};
								var store_tax = JSON.stringify(tax_data);
								localStorage.setItem("ptax_"+tax_name.value,store_tax);
								if (localStorage.getItem("ptax_"+tax_name.value)!= null) {
									var notice = document.getElementById("notice");
									notice.innerHTML = "success";
									notice.style.color = "red";
									document.getElementById("taxes-name").innerHTML = "";
									red_tax();
									tax_calculation();
									calculate_total();
									setTimeout(function(){
										notice.innerHTML="Tax Setup";
										notice.style.color = "black";
										tax_name.value = "";
										tax_amount.value = "";
										
									},2000);
									return false;
								}

							}
							else{
								alert("0 to 9 and % symobol are allowed");
								return false;
							}
						}
						else{
							alert("must use % symbol after tax amount");

						}
					}
				}
				else{

					alert("Do not use % symbol at first place");
				}
			}
		}
		else{
			alert("please add tax name");
		}
	}
}
set_tax();

// function read tax.........
function red_tax(){
	var i;
	for(i=0;i<localStorage.length;i++){
		var all_keys = localStorage.key(i);
		if (all_keys.match("ptax_")) {
			var keys_data = localStorage.getItem(all_keys);
			var red_data = JSON.parse(keys_data);
			var taxes_name = document.getElementById("taxes-name");
			taxes_name.innerHTML += "<p>"+red_data.tax_name+"- <span>"+red_data.tax+"</span></p><br>";
			

		}
	}
}

red_tax();

// tax_calculation...............

function tax_calculation(){
	var subtotal_amount = Number(document.getElementById("subtotal-amount").innerHTML);
	var taxes_name = document.getElementById("taxes-name");
	var span = taxes_name.getElementsByTagName("SPAN");
	document.getElementById("taxes-amount").innerHTML="";
	var i;
	for(i=0;i<span.length;i++){
		var num = span[i].innerHTML.replace("%","");
		var cal = (subtotal_amount*num)/100;
		var tofixed = cal.toFixed(2);
		var percantage = "<p class = 'fa fa-rupee'> "+tofixed+"</p><br><br>";
		document.getElementById("taxes-amount").innerHTML += percantage;

	}

}

// default tax coding..........
function default_tax(){
	var i;
	for(i=0;i<localStorage.length;i++){
		var all_keys = localStorage.key(i);
		if (all_keys.match("ptax_")) {
			var taxes_amount = document.getElementById("taxes-amount");
			var p = document.createElement("P");
			var br = document.createElement("BR");
			p.append(document.createTextNode("00.00"));
			taxes_amount.append(p);
			taxes_amount.append(br);
			
		}
	}
}

default_tax();

// calculate total................
function calculate_total(){
	var subtotal_amount = Number(document.getElementById("subtotal-amount").innerHTML);
	var taxes_name = document.getElementById("taxes-name");
	if (taxes_name!= "") {
			var taxes_amount = document.getElementById("taxes-amount");
			var p = taxes_amount.getElementsByTagName("P");
			var i;
			for(i=0;i<p.length;i++){
			subtotal_amount += Number(p[i].innerHTML);
			document.getElementById("total").innerHTML="<p class='fa fa-rupee' id='calculated-total'> "+subtotal_amount.toFixed(2)+"</p>";
		}
		paid();
	}

	else{
		document.getElementById("total").innerHTML="<p class='fa fa-rupee' id='calculated-total'> "+subtotal_amount+toFixed(2)+"</p>";
		paid();
	}
}

// calculate paid and dues..............
function paid(){
	var paid = document.getElementById("paid");
	paid.oninput=function(){
		var total = Number(document.getElementById("calculated-total").innerHTML);
		var dues = document.getElementById("dues");
		var dues_no = total-Number(this.value);
		dues.innerHTML= "<p class = 'fa fa-rupee' id='calculated-dues'> "+dues_no+"</p>";
	}

}