// url copy paste security 
function url_secure(){
	
	if (sessionStorage.length<=0) {
		var page = document.getElementById('contact-page');
		page.style.display = 'none';
		document.body.innerHTML="<h1>illegal action performed</h1>";
		document.body.style.background = 'black';
		document.body.style.color = 'white';
		document.body.style.fontSize = '50px';
		document.body.style.textAlign = 'center';
	}
}
url_secure();

window.onload=function(){
	var x = document.getElementById("contact").children.length;
	if (x==0) {
		document.getElementById("c-list").innerHTML="No contact list found !";
	}
}
function profile_pic(){
	var pic = document.getElementById("profile_pic");
	var user_mail = sessionStorage.getItem("user_mail");
	pic_name = localStorage.getItem(user_mail+"images_url");
	pic.style.background = "url("+pic_name+")";
	pic.style.backgroundSize = "cover";
	pic.style.backgroundRepeat = 'no-repeat';
}

profile_pic();

function add_contact(){
	var fullname  = document.getElementById("fullname").value;
	var pnum = document.getElementById("first_num").value;
	var snum = document.getElementById("second_num").value;
	if (fullname==""&&pnum==""&&snum=="") {
		window.alert("plese fill all fields");
	}
	else{
		if (pnum.length<10) {
			alert("please enter minimum 10 primary digit");
		}
		else{
			if (snum.length<10) {
				alert("plese enter minimum 10 digit secondry number");
			}
			else{
				var user = {fullname:fullname,pnum:pnum,snum:snum};
				var user_details = JSON.stringify(user);
				localStorage.setItem(fullname+"contact",user_details);
				var form = document.getElementById("form_contact");
				
				var notice = document.getElementById("contact_save_notice");
				notice.style.display = 'block';
				setTimeout(function(){var notice = document.getElementById("contact_save_notice");
				notice.style.display = 'none';},2000);
				window.location=location.href;

			}
		}
	}
}

// Show_contact function coding .........
function show_contacts(){
	var i;
	for(i=0;i<=localStorage.length;i++){
		var keys = localStorage.key(i);
		if (keys.match("contact")) 
		{
			
			var json_text = localStorage.getItem(keys);
			var json_extract = JSON.parse(json_text);
			var con = document.getElementById("contact");
			var fieldset = document.createElement("FIELDSET");
			var legend = document.createElement("LEGEND");
			var ol = document.createElement("OL");
			var li_one = document.createElement("LI");
			var li_two = document.createElement("LI");
			var trash  = document.createElement("I");
			trash.style.cursor = 'pointer';
			trash.setAttribute("title", "Delete Contact");
			trash.setAttribute("class","fa fa-trash");
			trash.setAttribute("id", "trash");
			var edit = document.createElement("I");
			edit.setAttribute("class", "fa fa-edit");
			edit.setAttribute("title", "edit contact");
			edit.setAttribute("id", "edit");
			var save = document.createElement("I");
			save.setAttribute("class", "fa fa-save");
			save.setAttribute("id", "save");
			save.setAttribute("title", "save contact");
			var saved = document.createElement("SPAN");
			con.appendChild(fieldset);
			fieldset.appendChild(legend);
			fieldset.appendChild(ol);
			ol.appendChild(li_one);
			ol.appendChild(li_two);
			ol.appendChild(trash);
			ol.appendChild(edit);
			ol.appendChild(save);
			ol.appendChild(saved);
			legend.appendChild(document.createTextNode(json_extract.fullname));
			li_one.appendChild(document.createTextNode(json_extract.pnum));
			li_two.appendChild(document.createTextNode(json_extract.snum));
			saved.appendChild(document.createTextNode("saved successfully !"));
			save.style.display="none";
			saved.style.color = "red";
			saved.style.float="right";
			saved.style.clear="both";
			saved.style.marginTop = "5px";
			saved.style.display = "none";
			delete_contact(keys,trash);
			edit_contact(keys,edit,save,saved);
			


		}
	}

}
show_contacts();

//delete contact coding...........

function delete_contact(contact_name,delete_button){
	delete_button.onclick=function(){
		var answer = confirm("Do you want to delete contact");
		if (answer==true) {
		ol=this.parentElement;
		fieldset=ol.parentElement;
		fieldset.remove();
		document.cookie = contact_name+"="+localStorage.getItem(contact_name)+";max-age=2592000";
		localStorage.removeItem(contact_name);
	}
			var x = document.getElementById("contact").children.length;
			if (x==0) {
				document.getElementById("c-list").innerHTML="No contact list found !";
			}
	}
}

// edit contact coding............
function edit_contact(contact_name,edit_button,save_btn,saved){
	edit_button.onclick = function(){
		save_btn.style.display = "block";
		var ol = this.parentElement;
		var fieldset = ol.parentElement;
		var legend = fieldset.getElementsByTagName("LEGEND")[0];
		legend.setAttribute("contenteditable", "true");
		legend.focus();
		var li = ol.getElementsByTagName("LI");
		var i;
		for(i=0;i<li.length;i++){
			li[i].setAttribute("contenteditable", "true");
			
		}
		var recent_legend;
		var current_legend;
		var recent_number = [];
		var current_number = [];
		legend.onclick=function(){
			recent_legend = this.innerHTML;
		}
		legend.onblur = function(){
			current_legend = this.innerHTML;
		}
		li[0].onclick = function(){
			recent_number[0] = this.innerHTML;
		}

		li[1].onclick = function(){
			recent_number[1] = this.innerHTML;
		}

		li[0].onblur = function(){
			current_number[0] = this.innerHTML;
		}

		li[1].onblur = function(){
			current_number[1] = this.innerHTML;
		}

		save_btn.onclick =function(){
			var edit_data = {fullname:current_legend==undefined?legend[0].innerHTML:current_legend,pnum:current_number[0]==undefined?li[0].innerHTML:current_number[0],snum:current_number[1]==undefined?li[1].innerHTML:current_number[1]};
			var final_data = JSON.stringify(edit_data);
			var txt = localStorage.getItem(contact_name);
			localStorage.setItem(contact_name, txt.replace(txt,final_data));
			saved.style.display="block";
			setTimeout(function(){saved.style.display="none";},2000);
		}
	}
}
// search contact coding............
function search_contact(user_input){
	var keyword = user_input.value.toUpperCase();
	var contact_list = document.getElementById("contact");
	var legend = contact_list.getElementsByTagName("LEGEND");
	var i;
	for(i=0;i<legend.length;i++){

		if (legend[i].innerHTML.toUpperCase().indexOf(keyword)!= -1) { 

			legend[i].parentElement.style.display ="block";
		}
		else{
			legend[i].parentElement.style.display = "none";
		}
	}
}

// restore contact........

function restore_contacts(){
	var page = document.getElementById("restore-contacts");
	page.style.display = "block";
	page.className = "animated slideInUp";
	var notice = document.querySelector("#restore-notice");
	if (document.cookie.length!=0) {
		notice.innerHTML = "Deleted Contacts";
		var divide_cookie = document.cookie.split(";");
		alert(divide_cookie);
	}
	else{
		notice.innerHTML = "NO Deleted Contacts";
	}


}


// logout coding...........

function logout(){
	var user = window.confirm("Do want to logout");
	if (user==true) {
		sessionStorage.clear();
		setTimeout(function(){
			window.open("../../../index.html","_self");
		},2000);
	}
}