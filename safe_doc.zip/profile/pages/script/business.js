
// company over effect coding...........
function company_effect(){
	var button = document.getElementsByTagName("BUTTON");
	var i;
	for(i=0;i<button.length;i++){
		button[i].onmouseover=function(){
			this.className="animated pulse";
		}
		button[i].onmouseout=function(){
			this.className = " ";
		}
	}
	
}

company_effect();

//model coding.............
function modal(){
	var model = document.getElementById("model");
	var btn = document.getElementsByTagName("BUTTON")[0];
	btn.onclick=function(){

 		if (model.offsetHeight==0) {
 			model.style.display = "block";
 			model.style.height = "300px";
 			model.className = "animated fadeInDown";
 			this.innerHTML="Close Company";
 		}
 		else{
 			model.className = "animated fadeOut";
 			model.style.height = "0";
 			this.innerHTML = "Create Company";
 		}
	}
}

modal();

// Company creation form
function company_val(){
	var cmp_name = document.getElementById("company_name");
	var maling_name = document.getElementById("maling_name");
	var address = document.getElementById("address");
	var phone_number = document.getElementById("phone_number");
	var fax = document.getElementById("fax");
	var email = document.getElementById("email");
	var website = document.getElementById("website"); 
	var stock = document.getElementById("stock");
	var financial_year = document.getElementById("financial-year");
	cmp_name.onchange=function(){
		if (isNaN(this.value)) {
			maling_name.onchange=function(){
				if (cmp_name.value==maling_name.value ) {
						this.value = "opps company name or maling name not same ";
						this.style.color = "red";
						this.style.borderColor="red";
						this.className="animated infinite pulse";
						this.onclick=function(){
							this.value ="";
							this.style.color="inherit";
							this.style.borderColor = "inherit";
							this.className="";
						}
				}
				else{

					if (this.value.indexOf(cmp_name.value+".pvt.ltd")!= -1|| this.value.indexOf(cmp_name.value+".govt.ltd")!=-1) {
							financial_year.onchange=function(){
								var current_date = new Date();
								var selected_date = new Date(this.value);
								if (selected_date.getFullYear()>=current_date.getFullYear()) {
									if (selected_date.getMonth()+1==4) {
										if (selected_date.getDate()==1) {
												var form = document.getElementById("form");
														form.onsubmit=function(){
														var cmp_details = {cmp_name:cmp_name.value,maling_name:maling_name.value,address:address.value,phone_number:phone_number.value,email:email.value,fax:fax.value,website:website.value,financial_year:financial_year.value,stock:stock.value};
														var cmp_data = JSON.stringify(cmp_details);
														localStorage.setItem("company",cmp_data);
													var model = document.getElementById("model");
													model.innerHTML="<center style='color:white'><i class='fa fa-check-circle' style='text-align:center;font-size:80px;color:red;'></i><br><h1  style='font-family:Ubuntu;font-size:30px;padding:0;margin:0;text-align:center;color:yellow'>Company created successfully.</h1><br><button id='click' style='backgrund:white;border:none;padding = 'inherit'10px';>click here</button></center>";
													var click = document.getElementById("click");
													click.onclick=function(){
														window.location=location.href;
													}
									
												}
										}
										else{
											this.type="text";
											this.value="opps!only 1st day  allowed";
											this.style.color = "red";
											this.style.borderColor = "red";
											this.className="animated infinite pulse";
											this.onclick=function(){
											this.type="date";
											this.style.color = "inherit";
											this.borderColor = "inherit";
											this.className="";
										}
									}

									}
									else{
										this.type="text";
										this.value="opps!only 4th months allowed";
										this.style.color = "red";
										this.style.borderColor = "red";
										this.className="animated infinite pulse";
										this.onclick=function(){
										this.type="date";
										this.style.color = "inherit";
										this.borderColor = "inherit";
										this.className="";
									}
								 }
								}
								else{
									this.type="text";
									this.value="opps! passed year not allowed";
									this.style.color = "red";
									this.style.borderColor = "red";
									this.className="animated infinite pulse";
									this.onclick=function(){
										this.type="date";
										this.style.color = "inherit";
										this.borderColor = "inherit";
										this.className="";
									}
								}
							}
					}
					else{
						this.value= "type company name.pvt.ltd or company name .govt.ltd";
						this.style.color = "red";
						this.style.borderColor = "red";
						this.className="animated infinite pulse";
						this.onclick=function(){
							 	this.value= "";
								this.style.color = "inherit";
								this.style.borderColor = "inherit";
								this.className="";
						}
					}
				}
			}
		}
		else{
			this.value="opps ! number are not allowed in company name";
			this.style.color = "red";
			this.style.borderColor = "red";
			this.className="animated infinite pulse";
			this.onclick=function(){
				this.value="";
				this.style.color = 'inherit';
				this.style.borderColor = "inherit";
				this.className="";
			}
		}
	}
}

company_val();
// company existed coding.......
function check_cmp(){
	if (localStorage.getItem("company")!= null) {
		document.getElementById("model").remove();
		var key_data = localStorage.getItem("company");
		var key_detail = JSON.parse(key_data);
		var brand_name = document.getElementById("create_btn");
		brand_name.innerHTML=key_detail.cmp_name;
		brand_name.style.color = "red";
		var cmp_icon = document.getElementById("create_company_icon");
		cmp_icon.className="fa fa-upload animated infinite flash";
		cmp_icon.title = "upload company icon";
		cmp_icon.onclick = function(){
			var input = document.createElement("INPUT");
			input.type="file";
			input.accept="/*";
			input.click();
			input.onchange=function(){
				
				if (this.files[0].size>512000) {
					alert("please upload less than 512 kb");
				}
				else {
					var reader = new FileReader();
					reader.readAsDataURL(this.files[0]);
					reader.onload= function(){
						localStorage.setItem("company_log",reader.result);
						window.location=location.href;
					}
					
				}
				
			}
		}
		brand_name.onclick=function(){
			var cmp_string = localStorage.getItem("company");
			var cmp_extract = JSON.parse(cmp_string);
			if (cmp_extract.stock=="account only") {
				window.location="./business_assest/accounts_only.html";
			}
			else if (cmp_extract.stock=="account with inventry") {
				window.location="./business_assest/account_with_inventry.html";
			}
			
		}

	}
}

check_cmp();
// show company logo coding........
function show_cmp_log(){
	if (localStorage.getItem("company_log")!=null) {
		var icon = document.getElementById("create_company_icon");
		icon.className="";
		icon.style.backgroundImage = "url("+localStorage.getItem("company_log")+")";
		icon.style.backgroundSize = "cover";
		
	}
	
}

show_cmp_log();
// company delete coding......
function del_company(){
	var del_btn = document.getElementById("delete_btn");
	del_btn.onclick=function(){
		var del_notice = document.getElementById("del_notice");
		if (localStorage.getItem("company")!= null) {
			del_notice.style.display = "block";
			del_notice.className="animated fadeInDown";
			var ok_btn = document.getElementById("ok_btn");
			ok_btn.onclick=function(){
				localStorage.removeItem("company");
				localStorage.removeItem("company_log");
				var i;
				for(i=0;i<localStorage.length;i++){
					var all_keys = localStorage.key(i);
					if (all_keys.match("tax")!=null) {
						localStorage.removeItem(all_keys);
					}
					if (all_keys.match("unit_mesure_")!=null) {
						localStorage.removeItem(all_keys);
					}
					if (all_keys.match("voucher_no")!=null) {
						localStorage.removeItem(all_keys);
					}
				}
				window.location = location.href;
			}
			var cancle_btn= document.getElementById("cancle_btn");
			cancle_btn.onclick=function(){
				del_notice.style.display ="none";
			}
		}

	}
}

del_company();

// company  log out coding.................
var logout_btn = document.getElementById("logout_btn");
logout_btn.onclick=function(){
	var logout_notice = document.getElementById("logout-notice");
	logout_notice.style.display = "block";
	sessionStorage.clear();
	setTimeout(function(){
		window.location="../../index.html";

	},2000);
	

}


// Show profile pic coding.............
function profile_pic_show(){
	var pic = localStorage.getItem(sessionStorage.getItem("user_mail")+"images_url");
	var profile_pic = document.getElementById("pic_box");
	profile_pic.style.background = "url("+pic+")";
	profile_pic.style.backgroundSize = "cover";

}

profile_pic_show();
