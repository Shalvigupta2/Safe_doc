// url copy paste security 
function url_secure(){
	
	if (sessionStorage.length<=0) {
		var page = document.getElementById('profile_page');
		page.style.display = 'none';
		document.body.innerHTML="<h1>illegal action performed</h1>";
		document.body.style.background = 'black';
		document.body.style.color = 'white';
		document.body.style.fontSize = '50px';
		document.body.style.textAlign = 'center';
	}
}
url_secure();



function stop_upload(){
	var profile_bg = document.getElementById('profile_bg');
	var app_con = document.getElementById("app-content");
	if (localStorage.getItem(sessionStorage.getItem('user_mail')+'images_url')!=null) {
		profile_bg.style.display = 'none';

	}
}
stop_upload();



function profile_name(){
	var result = document.getElementById("profile_name");
	var user_mail = sessionStorage.getItem('user_mail');
	var user_detail = localStorage.getItem(user_mail);
	var user_data = JSON.parse(user_detail);
	var user_name = atob(user_data.name);
	result.innerHTML=user_name;
}
profile_name();

function upload_profile_pic(){
	var input = document.getElementById('upload');
	if (input.files[0].size<1000000) {
	var freader = new FileReader();
	freader.readAsDataURL(input.files[0]);
	freader.onloadend = function(event){
		var show = document.getElementById("upload_pic");
		show.style.background ="url("+event.target.result+")";
		show.style.backgroundSize = "cover";
		show.style.backgroundRepeat = 'no-repeat';
		var icon = document.getElementById('upload_icon');
		icon.style.display = 'none';
		var ficon = document.getElementById('forward_icon');
		ficon.style.display = 'block';
		var img_url=event.target.result;
		ficon.onclick=function(){
			localStorage.setItem(sessionStorage.getItem("user_mail")+"images_url",img_url);
			var profile_bg = document.getElementById('profile_bg');
			profile_bg.style.display = 'none';
			document.getElementById("app-content").style.display = 'block';
			window.location=location.href;
		}
	}
	}
	else{
		alert("please upload less than 1 mb photo");
	}
}


// Start app cotent coding ..........

function showing_pic_name(){
	var name=document.getElementById("profile-name");
	var user_mail = sessionStorage.getItem("user_mail");
	var user_detail = localStorage.getItem(user_mail);
	var user_data = JSON.parse(user_detail);
	var fullname = user_data.name;
	name.innerHTML=atob(fullname);

	var pic_show = document.getElementById("profile-pic");
	var image_name = localStorage.getItem(user_mail+"images_url");
	pic_show.style.background = "url("+image_name+")";
	pic_show.style.backgroundSize = 'cover';
	pic_show.style.backgroundRepeat = 'no-repeat';
}

showing_pic_name();

function signout(){
	sessionStorage.clear();
	var notice = document.getElementById("notic").style.display = 'block';
	setTimeout(function(){
		window.location="../index.html";
	},2000);
}